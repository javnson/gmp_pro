/**
 * @file bh1730.h
 * @author Javnson (javnson@zju.edu.cn)
 * @brief 
 * @version 0.1
 * @date 2024-09-30
 * 
 * @copyright Copyright GMP(c) 2024
 * 
 */


#include <core/std/devif.h>

typedef stuct _tag_bh1730_device
{
    iic_gt iic_bus;


}bh1730_dt;

