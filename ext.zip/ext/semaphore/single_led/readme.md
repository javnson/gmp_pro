# Single LED Module

This module provided a single LED driver. By this module, user may implement a LED blink routine with facility.


